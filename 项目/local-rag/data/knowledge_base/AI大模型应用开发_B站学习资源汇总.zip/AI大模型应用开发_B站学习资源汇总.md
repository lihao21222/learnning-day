---
AIGC:
    Label: "1"
    ContentProducer: 001191440300708461136T1XGW3
    ProduceID: d78444a538bff4f0148f93c65053d77b_918497236f1611f195af5254002afed2
    ReservedCode1: BAPSALG4rVRgmfagGsglX6lHVEvzQLUFtirvbTRs3En3Oc68VIU3WEmIz3elkinBrbhtyeqNocXlBDBfPT2wfUezwa+pwflmbk8qd4k9feJzsYrFNeHqGAbO9ojvcScusgr2/+tHV0S1fkz1CfJrkaLnwNJtOlWnrsjBWabCmVXf9BYg2091YyUvyLw=
    ContentPropagator: 001191440300708461136T1XGW3
    PropagateID: d78444a538bff4f0148f93c65053d77b_918497236f1611f195af5254002afed2
    ReservedCode2: BAPSALG4rVRgmfagGsglX6lHVEvzQLUFtirvbTRs3En3Oc68VIU3WEmIz3elkinBrbhtyeqNocXlBDBfPT2wfUezwa+pwflmbk8qd4k9feJzsYrFNeHqGAbO9ojvcScusgr2/+tHV0S1fkz1CfJrkaLnwNJtOlWnrsjBWabCmVXf9BYg2091YyUvyLw=
---

# AI 大模型应用开发 B 站学习资源汇总

> 主线：API 调用 → RAG → Agent（三大核心能力，覆盖 80% 岗位需求）
>
> 整理时间：2026-06-23

---

## 阶段一：API 调用与框架入门（2-3 周）

### 核心教程（选 1 个跟学即可）

| 序号 | 教程名称 | 时长 | 亮点 | 链接 |
|------|----------|------|------|------|
| 1 | **翻遍整个B站，这绝对是2026讲的最好的AI大模型教程** | 约 15h | 从 API 调用到 Function Calling 全覆盖，适合零基础起步 | [BV1xTwrz2ETZ](https://www.bilibili.com/video/BV1xTwrz2ETZ/) |
| 2 | **【全666集】B站最全AI大模型零基础系统教程（2025版）** | 约 30h | 含 Transformer 原理 + LangChain + RAG + Agent，体系完整 | [BV1iK5DzHEg9](https://www.bilibili.com/video/BV1iK5DzHEg9/) |
| 3 | **【2026最新】LangChain 零基础全套教程** | 约 7h | 聚焦 LangChain V1.2，API 配置到 Agent 全流程 | [BV1Jy5T64EFi](https://www.bilibili.com/video/BV1Jy5T64EFi/) |

### 学习重点

- 注册并调通 DeepSeek / 通义千问 / OpenAI API
- 理解 temperature、token、system prompt、messages 结构
- Function Calling 原理与实战（让模型输出 JSON 触发函数）
- LangChain 核心模块（非全家桶）：Model、Prompt、Chain、Tool

### 产出入门项目

> 做一个"天气+日历查询助手"：用 Function Calling 调用天气 API 和日历 API，能回答"明天北京天气怎么样？后天我有会议吗？"

---

## 阶段二：RAG 检索增强生成（2-3 周）

### 核心教程（选 1-2 个跟学）

| 序号 | 教程名称 | 时长 | 亮点 | 链接 |
|------|----------|------|------|------|
| 1 | **【2025最新版】大模型RAG 入门到精通实战教程** | 约 12h | 从 Embedding 原理→向量数据库→企业级 RAG 全链路 | [BV1THLezcEXK](https://www.bilibili.com/video/BV1THLezcEXK/) |
| 2 | **【喂饭级教程】DeepSeek + RAGFlow 构建个人知识库** | 约 2h | 短平快，30 分钟跑通第一个知识库 | [BV14HdpYpEKx](https://www.bilibili.com/video/BV14HdpYpEKx/) |
| 3 | **【2025版】LangChain 打造 RAG 智能问答系统** | 约 4h | LangChain + RAG 实战，从模型接入到部署 | [BV1jG8MzGEvV](https://www.bilibili.com/video/BV1jG8MzGEvV/) |
| 4 | **2025 全网最详细 RAGFlow 教程** | 约 5h | 本地部署 + 知识库搭建 + API 封装 | [BV1TvdHYRE9w](https://www.bilibili.com/video/BV1TvdHYRE9w/) |

### 学习重点

- Embedding 模型原理与选择
- 文本分块策略（Chunking）
- 向量数据库：Chroma（入门）→ Milvus / Pinecone（进阶）
- 检索优化：相似度算法、重排序
- RAG 管道串联：文档加载 → 分块 → 向量化 → 检索 → 生成

### 产出入门项目

> 搭建一个"本地 PDF 知识库问答系统"：上传公司文档/论文，能基于文档内容回答问题并引用原文出处。

---

## 阶段三：Agent 智能体开发（3-4 周）

### 核心教程（选 1 个主跟 + 1 个补充）

| 序号 | 教程名称 | 时长 | 亮点 | 链接 |
|------|----------|------|------|------|
| 1 | **【2026版】B站最全智能体开发全套教程** | 约 20h | LangGraph 深入（节点控制/记忆/人机交互）+ CrewAI + 多个企业级实战 | [BV17RXpBbEpe](https://www.bilibili.com/video/BV17RXpBbEpe/) |
| 2 | **【2025版】AI Agent 智能体从 0 到 1 实战开发教程** | 约 22h | 保姆级，Agent 原理 + LangGraph + MCP + Coze/Dify 全涉及 | [BV13D2DB5EpC](https://www.bilibili.com/video/BV13D2DB5EpC/) |
| 3 | **【2025版】唯一将 Agent 智能体讲明白的教程** | 约 15h | 记忆系统深入讲解 + ReAct Agent + MCP 协议 | [BV1nRejzJErD](https://www.bilibili.com/video/BV1nRejzJErD/) |
| 4 | **黑马程序员 2026 LangChain+LangGraph 开发实战** | 约 25h | 机构出品，体系完整，适合系统学习 | 搜索"黑马程序员 LangGraph" |

### 补充实战开源项目（推荐）

| 项目 | 内容 | 链接 |
|------|------|------|
| **andysucao/ReActAgentsTest** | LangGraph+ReAct Agent 生产级实战，含记忆系统、MCP 集成、FastAPI 后端 | [GitHub](https://github.com/andysucao/ReActAgentsTest) |
| 对应 B 站视频 | 从零构建生产级 Agent 服务全套系列 | [BV1pcMbz9Epz](https://www.bilibili.com/video/BV1pcMbz9Epz/) |

### 学习重点

- Agent 核心循环：规划 → 执行 → 反思 → 迭代
- LangGraph：图编排、节点控制、状态管理、记忆检查点
- Function Calling / Tool Calling（深入）
- 记忆系统：短期记忆 + 长期记忆（向量库持久化）
- 多 Agent 协作（CrewAI / LangGraph 多智能体）
- MCP 协议（模型上下文协议，2026 年工具调用标准化趋势）
- Coze / Dify 低代码平台搭建 Agent（快速验证原型）

### 产出入门项目

> 做一个"数据分析 Agent"：上传 CSV → Agent 自动决策分析维度 → 调用 Python 工具分析 → 生成图表和文字报告。

---

## 推荐学习顺序与时间安排

```
第 1-2 周：阶段一（API 调用）
  └─ 教程 1（BV1xTwrz2ETZ），重点看 API 调用 + Function Calling 部分

第 3-5 周：阶段二（RAG）
  └─ 教程 1（BV1THLezcEXK）为主，教程 2（BV14HdpYpEKx）快速跑通知识库

第 6-9 周：阶段三（Agent）
  └─ 教程 1（BV17RXpBbEpe）为主，边学边写"数据分析 Agent"

第 10 周+：深挖
  └─ andysucao 开源项目跟练，学习生产级 Agent 架构
```

---

## 避坑提醒

1. **不要贪多**：每个阶段精选 1-2 个教程跟到底，比收藏 10 个有用得多
2. **先原生后框架**：阶段一先用 requests 直调 API 理解原理，再用 LangChain 提效
3. **必须写项目**：每学完一个阶段必须完成对应产出项目，只看不写等于白学
4. **不要跳阶段**：API 调用没搞懂就上 Agent 必然抓瞎，按顺序来
5. **MCP 是加分项不是必选项**：Agent 的核心是规划+工具调用，MCP 是协议层的标准化，掌握后再补即可
*（内容由AI生成，仅供参考）*
